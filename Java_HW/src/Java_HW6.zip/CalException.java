package Java_HW6;

public class CalException extends Exception{
	public CalException(){
		
	}
	public CalException(String msg){
		super(msg);
	}
}
