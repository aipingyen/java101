package Java_HW7;

public interface Pet {
	void speak();
}
